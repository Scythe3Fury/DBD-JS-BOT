module.exports = ({
name: "leaderboard",
aliases: "lb",
code: `$description[$userLeaderboard[Balance;asc]]
$title[Economy Leaderboards]
$footer[Used By $username]
$addTimestamp
$color[RANDOM]`
})