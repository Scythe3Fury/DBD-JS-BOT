module.exports = ({
name: "invite",
aliases: ["inv"],
code: `$title[Invite me!]
$description[Invite Link - [Click Here\\]($getBotInvite)
$footer[Requested by - $username]
$color[RANDOM]`
})