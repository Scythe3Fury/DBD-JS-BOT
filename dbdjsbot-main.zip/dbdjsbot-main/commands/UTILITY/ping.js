module.exports = ({
name: "ping",
code: `**WB Ping - \`$ping\` ms
Ping - \`$botPing\` ms**
`
})