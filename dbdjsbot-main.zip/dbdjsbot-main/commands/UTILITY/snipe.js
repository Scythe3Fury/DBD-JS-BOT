module.exports = ({
name: "snipe",
code:`$author[$userTag[$getchannelvar[user_ID]];$useravatar[$getchannelvar[user_ID]]]
$description[$getChannelVar[user_message]]
$footer[Sniped $addTimestamp]
$color[00ffff]`
})