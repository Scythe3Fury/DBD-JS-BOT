module.exports = ({
name: "uptime",
code: `$description[$uptime]
$color[00FFFF]
$footer[UPTIME]`
})