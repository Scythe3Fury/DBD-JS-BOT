module.exports = ({
name: "help",
Aliases: "h",
code: `$author[$username[$clientID] Commands;$authorAvatar] 
$addField[:ring:**OTHERS**:ring:;
\`Captcha/Code\`, \`CovidInfo\`, \`ClydeSay\`, \`Whois\`, \`Gayrate\`, \`Simprate\`, \`8Ball\`, \`Panda\`, \`Puppy\`, \`Cat\`, \`Bear\`, \`cry\`]
$addField[🎵**MUSIC**🎵;
\`Play\`, \`Stop\`, \`Lyrics\`, \`Skip\`, \`Pause\`, \`Resume\`, \`Queuelist\`, \`Volume\`]
$addField[💰**ECONOMY**💰;
\`Profile\`, \`Shop\`, \`Buycar\`, \`Buyphone\`, \`Buytv\`, \`Buytruck\`, \`Buylaptop\`, \`Buyheli\`, \`Buyhouse\`, \`Buyaparment\`, \`Buymansion\`, \`Buybag\`, \`Buyspiteful\`, \`Openspiteful\`, \`Buylucky\`, \`Openlucky\`, \`Balance\`, \`Withdraw\`, \`Deposit\`, \`Work\`, \`Beg\`, \`Heist\`, \`Leaderboard\`, \`Givemoney\`, \`Rob\`, \`ResetEconomy\`]
$addField[:game_die:**CASINO**:game_die:;
\`CoinFlip\`]
$addField[:medal:**RANK**:medal:;
\`Setrank\`, \`Setrankmsg\`, \`Resetrank\`, \`Rank/level\`]
$addField[:tickets:**TICKETS**:tickets:;
\`Ticketsetup\`, \`Ticket\`, \`Close\`]
$addField[:rofl:**FUN**:rofl:;
\`Say\`, \`ImageSay\`, \`Guess\`, \`Meme\`, \`Avatar\`, \`Drip\`, \`Milk\`, \`Heaven\`, \`DockOfShame\`, \`Rip\`, \`Rps\`, \`Stonks\`, \`Slap\`, \`Firsttime\`, \`Tweet\`, \`Wasted\`, \`Wanted\`,]
$addField[🛠️**MODERATION**🛠️;
\`Nuke\`, \`Channel-Lock/Unlock\`, \`Purge\`, \`Antilink\`, \`Kick\`, \`Ban/Unban\`, \`Warn\`, \`CheckWarn\`, \`ClearWarn\`, \`Setmute\`, \`Mute\`, \`Unmute\`, \`Tempmute\`]
$addField[🔰**UTILITY**🔰;
\`Help\`, \`Invite\`, \`Ping\`, \`Uptime\`, \`Setprefix\`,\`Snipe\`, \`Embed\`, \`ServerInfo\`, \`BotInfo\`]
$color[RANDOM]
$thumbnail[$userAvatar[$clientID]]
`
})
