module.exports = ({
name: "wasted",
code: `$argsCheck[1;Please Mention Someone To Wasted!]
$image[https://some-random-api.ml/canvas/wasted?avatar=$userAvatar[$mentioned[1]]]`
})