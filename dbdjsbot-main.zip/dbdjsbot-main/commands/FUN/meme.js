module.exports = ({
name: "meme",
code: `$title[ALL MEMES HERE]
$image[https://ctk-api.herokuapp.com/meme/$random[1;500]]
$footer[Used by $username]
$color[00FFFF]
$addTimestamp`
})