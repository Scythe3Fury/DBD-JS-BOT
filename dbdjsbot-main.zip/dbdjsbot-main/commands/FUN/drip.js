module.exports = ({
name: "drip",
code: `$image[https://vacefron.nl/api/drip?user=$userAvatar[$mentioned[1]][&]
 $color[RANDOM]`
})