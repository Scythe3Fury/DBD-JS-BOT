module.exports = ({
name: "dockofshame",
aliases: ['dos'],
code: `$image[https://vacefron.nl/api/dockofshame?user=$userAvatar[$mentioned[1]][&]
 $color[RANDOM]`
})