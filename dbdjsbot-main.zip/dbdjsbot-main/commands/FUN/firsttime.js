module.exports = ({
name: "firsttime",
aliases: ['ft'],
code: `$image[https://vacefron.nl/api/firsttime?user=$userAvatar[$mentioned[1]]]
 $color[RANDOM]`
})
