module.exports = ({
name: "say",
code: `$message
$deletecommand`
})