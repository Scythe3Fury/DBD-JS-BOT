module.exports = ({
name: "heaven",
code: `$image[https://vacefron.nl/api/heaven?user=$userAvatar[$mentioned[1]][&]
 $color[RANDOM]`
})