module.exports = ({
name: "milk",
code: `$image[https://vacefron.nl/api/icanmilkyou?user1=$userAvatar&user2=$userAvatar[$mentioned[1]]]
$color[RANDOM]`
})