module.exports = ({
name: "imgsay",
code: `$deletecommand
$image[https://flamingtext.com/net-fu/proxy_form.cgi?script=3d-logo&text=$message[1]+$message[2]+$message[3]+$message[4]+$message[5]+$message[6]+$message[7]+$message[8]+$message[9]+$message[10]+$message[11]+$message[12]+$message[13]+$message[14]+$message[15]+$message[16]+$message[17]+$message[18]+$message[19]+$message[20]+&_loc=generate&imageoutput=true]
$color[$random[0;999999]]`
})