module.exports = ({
name: "stonks",
code: `$image[https://vacefron.nl/api/stonks?user=$userAvatar[$mentioned[1]][&notstonks=BOOL]]
 $color[RANDOM]`
})