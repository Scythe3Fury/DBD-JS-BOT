module.exports = ({
name: "rip",
code: `$image[https://vacefron.nl/api/grave?user=$userAvatar[$mentioned[1]][&]
 $color[RANDOM]`
})