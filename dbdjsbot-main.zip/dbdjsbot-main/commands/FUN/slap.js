module.exports = ({
name: "slap",
code: `$image[https://vacefron.nl/api/batmanslap?text1=AAAA!&text2=LUUUU&batman=$userAvatar&robin=$userAvatar[$mentioned[1]]]
$color[RANDOM]`
})