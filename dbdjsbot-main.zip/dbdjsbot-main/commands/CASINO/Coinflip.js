module.exports = ({
    name: "coinflip",
    aliases: "cf, coinf, cflip",
    code: `
    $color[#ff0000]
    $title[The coin is fliped and it is...]
    $description[$randomText[Head;Tail]\` !\`]
    $footer[COINFLIP]
    `})
