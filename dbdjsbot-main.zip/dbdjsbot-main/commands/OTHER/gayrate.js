module.exports = ({
name: "gayrate",
code: `$argsCheck[>1;Please Mention Someone]
$title[GAYRATE]
$color[RANDOM]
$description[$username[$mentioned[1;yes]]$random[1;100]% Gay]
$footer[You Are A Gay]`
})