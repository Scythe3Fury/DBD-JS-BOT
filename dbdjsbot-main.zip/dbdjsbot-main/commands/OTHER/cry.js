module.exports = ({
name: "cry",
code: `$title[$username Is Crying]
$description[]
$footer[]
$color[226EB3]
$image[$randomText[https://pa1.narvii.com/6856/0fa256c21511472a145a544742c8d20f771bc01b_hq.gif; https://i.pinimg.com/originals/3b/99/c3/3b99c394a306d04b8462f3ae781302bf.gif; https://i.pinimg.com/originals/9a/0d/e8/9a0de8b0861406d2d04fab7160e74be1.gif;https://cdn.discordapp.com/attachments/797106486382952458/802987901385179167/tenor.gif;https://cdn.discordapp.com/attachments/797106486382952458/802987900949102662/tenor_1.gif;https://cdn.discordapp.com/attachments/797106486382952458/802987900265824346/anime-cry.gif]]`
})