module.exports = ({
name: "eval",
code: `$eval[$message] $onlyForIDs[$botOwnerID;710129159342653590;{description:Error} {color:RED}]`
})