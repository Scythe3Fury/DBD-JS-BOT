module.exports = ({
name: "resume",
code: `$resumeSong Successfully resumed the song.
$onlyIf[$voiceID!=;To resume music, please join a VC.]`
})