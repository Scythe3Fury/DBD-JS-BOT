module.exports = ({
name: "volume",
code: `Successfully set the volume to $message.
$volume[$message]
$suppressErrors[What do you want your volume set as? use a number.]`
})