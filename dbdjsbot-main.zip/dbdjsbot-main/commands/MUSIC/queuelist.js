module.exports = ({
name: "queuelist",
code: `$queue
$onlyIf[$voiceID!=;To See Queuelist, Please Join To Voice Channel To See Queuelist .]`
})