module.exports = ({
name: "skip",
code: `Skipped the song. $skipSong
$onlyIf[$voiceID!=;To skip music, please join a VC.]`
})