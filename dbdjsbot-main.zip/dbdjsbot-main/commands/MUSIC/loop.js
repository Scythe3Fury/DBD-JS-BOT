module.exports = ({
name: "loop",
code: `$loopqueue Looped queue.
$onlyif[$voiceId=!;you need to be in voice channel]`
})