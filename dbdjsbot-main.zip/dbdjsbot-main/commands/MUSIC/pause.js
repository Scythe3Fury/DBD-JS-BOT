module.exports = ({
name: "pause",
code: `Successfully paused the song. $pauseSong
$onlyIf[$voiceID!=;To pause music, please join a VC.]`
})