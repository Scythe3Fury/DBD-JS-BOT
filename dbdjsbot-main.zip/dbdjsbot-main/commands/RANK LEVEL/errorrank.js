module.exports = ({
name: "errorrank",
code: `$setServerVar[rch;]
$onlyForServers[$guildID;]`
})